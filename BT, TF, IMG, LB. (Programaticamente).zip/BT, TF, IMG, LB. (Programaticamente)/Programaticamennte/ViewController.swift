//
//  ViewController.swift
//  Programaticamennte
//
//  Created by Macbook on 6/28/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
        let panda = "🐼"

    var etiqueta : UILabel = {
        var et = UILabel()
        et.text = "Escrebe algo abajo y despues presiona el boton"
        et.numberOfLines = 2
        et.adjustsFontSizeToFitWidth = true // ajusta el tamaño de la funte cuando ya no cabe.
        et.textAlignment = .center //rigth, left, justified
        et.textColor = .black
        //et.highlightedTextColor = UIColor.red
       // et.isEnabled = false
        et.font = UIFont.systemFont(ofSize: 25)
        et.translatesAutoresizingMaskIntoConstraints = false
        et.layer.cornerRadius = 50
        et.backgroundColor = UIColor.white
       // et.backgroundColor = UIColor(displayP3Red: 0.2, green: 0.4, blue: 0.5, alpha: 1)
        //et.backgroundColor = UIColor(patternImage: UIImage(named: "Vane")!)
        
        return et
    }()
    
    var boton : UIButton = {
       var bt = UIButton(type: .system)
        bt.setTitle("Click", for: .normal)
        bt.setTitleColor(UIColor.black, for: .normal)
        bt.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        bt.addTarget(self, action: #selector(texto), for: .touchUpInside)
        bt.backgroundColor = UIColor.green

        bt.layer.cornerRadius = 5
        bt.translatesAutoresizingMaskIntoConstraints = false
        return bt
    }()
    
    
    let imagen : UIImageView = {
       let im = UIImageView()
        im.image = UIImage(named: "Vane-1")
        
        return im
    }()
    
    @objc func texto(){
        etiqueta.text =  textField.text
    }
    
    var textField : UITextField = {
       var tf = UITextField()
       tf.backgroundColor = .white
        tf.textColor = .black
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.textAlignment = .center
        tf.placeholder = "Escribe algo"
        return tf
    }()
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(etiqueta)
        view.addSubview(boton)
        view.addSubview(imagen)
        view.addSubview(textField)
        
        view.backgroundColor = UIColor.cyan
        
        textField.frame = CGRect(x: 10, y: 200, width: 400, height: 100)
       imagen.frame = CGRect(x: 50, y: 500, width: 300 , height: 150)
        etiqueta.frame = CGRect(x: 10 , y: 50, width: 400, height: 100)
        boton.frame = CGRect(x: 10, y: 350, width: 400, height: 100)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
}

