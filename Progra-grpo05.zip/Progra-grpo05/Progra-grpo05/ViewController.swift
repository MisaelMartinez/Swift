//
//  ViewController.swift
//  Progra-grpo05
//
//  Created by Germán Santos Jaimes on 4/17/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class AlumnoViewController: UIViewController {

    var etiqueta: UILabel = {
        var label = UILabel()
        label.text = "Esto es un Texto"
        label.font = UIFont.systemFont(ofSize: 46)
        label.textColor = UIColor.white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var label2: UILabel = {
        var label = UILabel()
        label.text = "Esta es la revancha"
        label.font = UIFont.systemFont(ofSize: 30)
        label.textColor = UIColor.white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var boton: UIButton = {
        var btn = UIButton(type: .system )
        btn.setTitle("Click", for: .normal )
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        btn.addTarget(self, action: #selector(test), for: .touchUpInside)
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 5
        btn.translatesAutoresizingMaskIntoConstraints = false

        return btn
    }()
    
    var texto: UITextField = {
        var txt = UITextField()
        txt.textColor = UIColor.white
        txt.sizeToFit()
        txt.translatesAutoresizingMaskIntoConstraints = false
        return txt
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
        
        view.addSubview(etiqueta)
        view.addSubview(label2)
        view.addSubview(boton)
        view.addSubview(texto)
        
        
        etiqueta.topAnchor.constraint(equalTo: view.topAnchor, constant: 120).isActive = true
        etiqueta.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        label2.topAnchor.constraint(equalTo: etiqueta.bottomAnchor, constant: 50).isActive = true
        label2.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    
        boton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        boton.topAnchor.constraint(equalTo: label2.bottomAnchor, constant: 50).isActive = true
        
        texto.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        texto.topAnchor.constraint(equalTo: boton.bottomAnchor, constant: 50).isActive = true
        
    }
    
    @objc func test(){
        print("Click")
    }

}

