//
//  ViewController.swift
//  Animate_gpo05
//
//  Created by Germán Santos Jaimes on 4/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.green
        
        setupView()
        anima()
        
    }

    let imagen: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(named: "queen")
        iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 50
        iv.layer.masksToBounds = true
        return iv
    }()
    
    func setupView(){
        view.addSubview(imagen)
        
        imagen.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        imagen.center.x -= view.bounds.width
    }
    
    func anima(){
        
//        UIView.animate(withDuration: 1.0) {
//            self.imagen.center.x = self.view.bounds.width
//        }
        
        UIView.animate(withDuration: 1.0, delay: 0.5, options: [.repeat, .autoreverse, .curveEaseOut ], animations: {
            self.imagen.center.x = self.view.bounds.width
            self.imagen.frame.size.width += 200
            self.imagen.frame.size.height += 200
            self.imagen.alpha = 0.1
        }, completion: nil)
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        self.imagen.center.y += 100
//        self.imagen.alpha = 0.0
//        print("viewwillAppear")
//    }
//
//    override func viewDidAppear(_ animated: Bool) {
//        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.0, options: [], animations: {
//            self.imagen.center.y -= 100
//            self.imagen.alpha = 1.0
//            print("viewDidAppear")
//        }, completion: nil)
//    }
    
    
}

