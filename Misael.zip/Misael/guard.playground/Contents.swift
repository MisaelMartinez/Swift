//: Playground - noun: a place where people can play

class FelizCumpleaños{
    let numeroInvitados : Int?
    
    init?(numeroInvitados: Int?) {
        if numeroInvitados == 0{
            self.numeroInvitados = nil
        }else{
            self.numeroInvitados = numeroInvitados
        }
    }

    
    
    
}

let alan = FelizCumpleaños(numeroInvitados: nil)


print(alan?.numeroInvitados! as Any)
