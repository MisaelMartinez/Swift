
var bottleCount = 0

func imprimir(){
bottleCount = 99
print(bottleCount)
}

imprimir()
print(bottleCount)


func printTenNames() {
    let name = "Grey"
    for index in 1...10 {
        print("\(index): \(name)")
    }
   // print(index)
    print(name)
}

printTenNames()


func printComplexScope() {
    let points1 = 100
    print(points1)
    
    for index in 1...3 {
        let points = 200
        print("Loop \(index): \(points+index)")
    }
    
    print(points1)
}

printComplexScope()




//ENUMERACIONES

enum Numeros {
    case numero1,numero2,numero3,numero4,numero5
    
}

enum Numeros2 {
    case numero1
    case numero2
    case numero3
    case numero4
    //...
    case numero5
}

var numeroA : Numeros = .numero2
numeroA = Numeros.numero1
print(numeroA)



if numeroA == .numero1{
    print("nada")
}


switch numeroA {
case .numero1:
    print("1")
case .numero2:
    print("2")
case .numero3:
    print("3")
case .numero4:
    print("4")
case .numero5:
    print("5")
    
    
}

struct Alumno {
   var numeroDAlumno : Numeros
    let nombre : String
}

let misael = Alumno(numeroDAlumno: .numero2, nombre: "Vanessa")

print(misael.numeroDAlumno)
















