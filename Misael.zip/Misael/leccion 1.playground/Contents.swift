import UIKit

//Operador ternario
let a : Double = 10.3
let b : Double = 19.3
var c : Double

c = a > b ? a : b

print(c)

// operadores.

var numero : Int = 10

numero += 2
numero *= 2
numero -= 2
numero /= 2

// Swich

var distancia : Double = 9.9

switch distancia {
case 0...10:
    print("Hola")
    distancia += 0.1
default:
    print("Adios")
}

//String


let joke = """
Q: Why did the chicken cross the road?
A: To get to the other side!
"""
print(joke) //Comillas triples """ son para saltos de linea

let hola = "En programacion es tradicional escribir primero un \"Hola mundo\"."
let hola2 = "En programacion es tradicional escribir primero un \'Hola mundo\'."
let hola3 = "En programacion es tradicional escribir primero un \\Hola mundo\\."
let hola4 = "En programacion es tradicional escribir primero un \tHola mundo\t."
let hola5 = "En programacion es tradicional escribir primero un \r    Hola mundo\r\r\r."
print("""
    \(hola)
    \(hola2)
    \(hola3)
    \(hola4)
    \(hola5)
    """) // \"...\" son para imprimir comillas.


let estaVacio = ""
if estaVacio.isEmpty{
    print("Esta vacio")
}

let noEstaVacio = " "
if !noEstaVacio.isEmpty{
    print("No esta vacio")
}

var  string = "Hola"
var string2 = ", mundo."
print("\(string)\(string2)")
string = string + string2
print(string)


print(string.lowercased()) //imprime todas minuscilas
print(string.count)

