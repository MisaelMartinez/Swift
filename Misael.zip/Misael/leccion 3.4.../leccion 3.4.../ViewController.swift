//
//  ViewController.swift
//  leccion 3.4...
//
//  Created by Macbook on 7/10/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
        print("Hola mundo 3 - Despues de que aparece la vista \r\r")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Hola mundo 1 - primero se carga la vista")
        view.backgroundColor = .red
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Hola mundo 2 - Antes de mostrar la vista")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("Hola mundo 4 - Antes de que desaparezca la vista")
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        print("Hola mundo 5 - Ya desaparecio la vista")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

