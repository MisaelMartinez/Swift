//: Playground - noun: a place where people can play

import UIKit

//Funciones

func multiplicaPorTres(numero : Int) -> Int{
    let resultado = numero * 3
    //resultado *= 3
    return resultado
    
}

print(multiplicaPorTres(numero: 3))

func comentaYMultiplica(comentario : String, numero : Int = 0){
    print("\(comentario) \(numero)")
}


comentaYMultiplica(comentario: "El numero a impirmir es:", numero: 100)
comentaYMultiplica(comentario: "El numero a impimir es: ")


//Estructuras

struct Persona {
    let Nombre : String
    var edad : Int
    let Genero : String
    let isBeautiful : Bool
    
    func ImprimeDatos(){
        print("""
            El nombre de la persona es: \(Nombre)
            Tiene \(edad) años
            Es \(Genero)
        """)
      
        guard isBeautiful else { print("\tno es guapa"); return}
        print("\tSi es guapa\r\r")
        
    }
    
}
    
    

let Vane = Persona(Nombre: "Vanessa", edad: 16, Genero: "Femenino", isBeautiful: true)

Vane.ImprimeDatos()


struct money{
   var  peso : Double
    
    init(peso: Double) {
        self.peso = peso
    }
    
    init(dolar : Double) {
        peso = dolar*19.4
    }
    
    init(euro: Double) {
        peso = euro*22.65
    }

    
}

let dineroEuero = money(euro: 20.6)
let dineroDolar = money(dolar: 3.50)
let dineroPesos = money(peso: 50.50)

print(dineroDolar.peso, dineroPesos.peso, dineroEuero.peso, "\r")


struct suma {
  let  numero1 : Int
    let numero2 : Int
    
    func sumaNumeros() -> Int {
        return (numero1 + numero2)
    }
}

var resultado = suma(numero1: 20, numero2: 34)
var hola = resultado.sumaNumeros()
print("\r",hola)


//Clases

class Continente {
    var continente : String
    
    
    init(continente :  String){
        self.continente = continente
    }
    
}

class Pais : Continente{
    var pais = " "
    
    init(continente : String, pais : String) {
        self.pais = pais
        super.init(continente: continente)
    }
    
}

class estado : Pais {
    var estado = " "
    
    init(estado: String, continente: String, pais: String) {
        self.estado = estado
        super.init(continente: continente, pais: pais)
    }
}

var Colonia = estado(estado: "Mexico", continente: "America", pais: "Mexico")
var yo = Colonia

Colonia.estado = "Estados Unidos Mexicanos"

print(yo.estado) // Herencia

// Arrays = Arreglos.--------------------------------------------

var array : [Int] = [2,6,2,5,7,2,1,4] // = [Int]() o :[Int] = []
array.contains(3)

var name = ["Misael"]
name.append("Joe")
name += ["Vane", "Juan"]
name.insert("misael", at: 0) //Recorre todos los elementos despues de la indice agregado.

print(name)

name.remove(at: 2)
name.removeLast()
name.removeFirst()

var name2 = name
print(name)

var nombres = name + name2

print(nombres)




var arregloNum1 = [1,2,3]
var arregloNum2 = [4,5,6]

var ArregloNumeros = [arregloNum1,arregloNum2]
print("\r",ArregloNumeros)
print(ArregloNumeros[0])
print(ArregloNumeros[0][0])

print("\r", ArregloNumeros)
print(ArregloNumeros[1])
print(ArregloNumeros[1][0])


//Diccionarios

var Score = ["Misael": 100,
             "Vane": 200,
             "La Yaids": 500]

Score.updateValue(300, forKey: "Vane")

print(Score)
print(Score["Vane"]!)
Score["Misael"] = nil // Score.removeValue(key: String)
print(Score)

var DicVarios = [1: ("Hola", 12,12.3,"Adios")]

print((DicVarios[1]?.2)!)






