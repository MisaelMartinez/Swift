//
//  ViewController.swift
//  slider
//
//  Created by Macbook on 7/7/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var slider : UISlider = {
        let slider = UISlider()
        
        slider.thumbTintColor = .red
        slider.maximumValue = 100
        slider.minimumValue = 0
        slider.maximumTrackTintColor = .black
        slider.minimumTrackTintColor = .orange
        slider.addTarget(self, action: #selector(cambiColor), for: .touchDragInside)
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()

    @objc func cambiColor(){
        
        let valor = Int(slider.value)
        print(valor)
        switch valor {
        case 0...90:
            view.backgroundColor = UIColor(red: CGFloat(slider.value/100), green: CGFloat(slider.value/100), blue: CGFloat(slider.value/100), alpha: 1)
        default:
            view.backgroundColor = .red
        }
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        
        view.addSubview(slider)
        
        
        
        slider.frame = CGRect(x: 30, y: 100, width: 200, height: 20)
        slider.value = 50
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}

