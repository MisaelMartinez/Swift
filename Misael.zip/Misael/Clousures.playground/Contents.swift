//: Playground - noun: a place where people can play

import UIKit


func suma(numero : [Int ]) -> Int{
    
    
   
    var sumaNumero : Int = 0
    
    for n in numero{
        
    sumaNumero = sumaNumero + n
      
        
    }
    
    print(sumaNumero)
    return sumaNumero
    
}


let numero = [1,8,2,5,1]
suma(numero: numero)


let sumClousure = { (numeroClosure : [Int]) -> Int in
    var sumaNumeroClosure = 0
    for n in numeroClosure{
        sumaNumeroClosure += n
    }
    
    return sumaNumeroClosure
}


let sumaClosure = sumClousure(numero)



let printf = { () -> Void in
print("El amor de mi vida es Vane y me encanta mucho")
}


let numAleatorio = arc4random_uniform(7) + 7

print(numAleatorio)


struct Track {
   var  trackNumber : Int
    
}

let tracks = [Track(trackNumber : 3), Track(trackNumber: 2), Track(trackNumber: 1), Track(trackNumber: 0)]

//let sortedTrack = tracks.sorted { (track1, track2 )  in return track1.trackNumber < track2.trackNumber}

let sortedTrack = tracks.sorted { $0.trackNumber < $1.trackNumber}
for n in sortedTrack{
print(n)
}




// For con Clousure y map


let nombres = ["Misael", "Vanessa", "Juan", "Misael"]

//var nombresCompletos : [String] = []
//
//for nombre in nombres {
//    let nombreCompleto = nombre + " Smith"
//    nombresCompletos.append(nombreCompleto)
//}
//
//for n in nombresCompletos {
//    print(n)
//}


//var nombresCompletos = nombres.map { (name) -> String in
//    return name + " Smith"
//}

var nombresCompletos = nombres.map { $0 + " Smith"}

for n in nombresCompletos {
    print(n)
}



// Filter()

let numbers = [1,5,7,2,4,8,3,3,3,3]

var newNumbers = numbers.filter { $0 < 5}
print(newNumbers)

var newNumbers2 = newNumbers.sorted() { $0 < $1 }

print(newNumbers2)

// Reduce()  con numbers ^

var acum = 0

for n in numbers{
    acum += n
}
 print(acum)

var acum2 = numbers.reduce(0) { (numero1, numero2) -> Int in
    return numero1 + numero2
}
print(acum2)

var AcumReduce = numbers.reduce(0,{ $0 + $1 })
print(AcumReduce)




