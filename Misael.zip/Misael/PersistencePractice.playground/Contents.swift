//: Playground - noun: a place where people can play

import UIKit

struct Note: Codable {
    let title: String
    let text: String
    let timestamp: Date
    
}


let newNote = Note(title: "Grocery run", text: "Pick up mayonnaise, mustard, lettuce, tomato, and pickles.", timestamp: Date())

let newNote2 = Note(title: "Primer ", text:"Entro el 6 de agosto a la escuela", timestamp: Date())

let newNote3 = Note(title: "Amo a mi novia", text: "Es la mejor de lo mejor y jamas pienso dejarla.", timestamp: Date())

let notes = [newNote,newNote2,newNote3]





let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!

let archivoURL = documentsDirectory.appendingPathComponent("notes_test").appendingPathExtension("plist")

let propertyListEncoder = PropertyListEncoder()
let encodeNote = try? propertyListEncoder.encode(notes)
try? encodeNote?.write(to: archivoURL, options: .noFileProtection)
print(notes)

let propertylistDecoder = PropertyListDecoder()
if let retrievedNoteData = try? Data(contentsOf: archivoURL), let decodedNote = try? propertylistDecoder.decode(Array<Note>.self, from: retrievedNoteData){
    print(decodedNote)
}


