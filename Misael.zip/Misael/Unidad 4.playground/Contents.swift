//: Playground - noun: a place where people can play

import UIKit

class Uni4 : CustomStringConvertible {
    let frase : String
    let numero : Int
    let Si : Bool
    
    init(frase: String, numero: Int, Si :  Bool) {
        self.frase = frase
        self.numero = numero
        self.Si = Si
    }
    
    var description: String{
        
        let si = Si ? "Hola" : "Adios"
        
        return "(frase: \(frase), numero: \(numero)), Si : \(si)"
    }
    
}

let YoMero = Uni4(frase: "Hola, ¿como estas?", numero: 10, Si: false)

print(YoMero)


//Equatable




struct Employee: Equatable, Comparable, Codable{
    var firstName: String
    var lastName: String
    var jobTitle: String
    var phoneNumber: String
    
    static func ==(izquierda : Employee, derecha: Employee) -> Bool{
   
            return izquierda.firstName == derecha.firstName && izquierda.jobTitle == derecha.jobTitle && izquierda.lastName == derecha.lastName && izquierda.phoneNumber == derecha.phoneNumber
        }
    
    static func < (izquierda: Employee, derecha : Employee) -> Bool{
        return izquierda.firstName < derecha.firstName
        
    }
}

struct Company {
    var name: String
    var employees: [Employee]
}

let currentEmployee = Employee(firstName: "Daren", lastName: "Estrada", jobTitle: "Product Manager", phoneNumber: "415-555-0692")
let selectEmployee = Employee(firstName: "Jacob", lastName: "Edwards", jobTitle: "Marketing Director", phoneNumber:"415-555-9293")

if currentEmployee == selectEmployee{
    print("Hola, si es igual.")
}else { print("Adios, no es igual.")}


let employee1 = Employee(firstName: "Ben", lastName: "Atkins",
jobTitle: "Front Desk", phoneNumber: "415-555-7767")
let employee2 = Employee(firstName: "Vera", lastName: "Carr",
                         jobTitle: "CEO", phoneNumber: "415-555-7768")
let employee3 = Employee(firstName: "Grant", lastName: "Phelps",
                         jobTitle: "Senior Manager", phoneNumber: "415-555-7770")
let employee4 = Employee(firstName: "Sang", lastName: "Han",
                         jobTitle: "Accountant", phoneNumber: "415-555-7771")
let employee5 = Employee(firstName: "Daren", lastName:
    "Estrada", jobTitle: "Sales Lead", phoneNumber: "415-555-7772")

let employe = [employee1,employee2, employee3, employee4, employee5 ]

let sortedEmployee = employe.sorted(by: <)

for n in sortedEmployee{
    print(n)
}


let ben = Employee(firstName: "Ben", lastName: "Atkins",
jobTitle: "Front Desk", phoneNumber: "415-555-7767")

let jsonEncoder = JSONEncoder()
if let jsonData = try? jsonEncoder.encode(ben),
    let jsonString = String(data: jsonData, encoding: .utf8) {
    print(jsonString)
}

