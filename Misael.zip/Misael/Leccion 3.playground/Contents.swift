//: Playground - noun: a place where people can play

import UIKit

var numero : Int?

numero = nil

print(numero as Any)

if numero == nil {
    numero = 10
    print(numero!)
}else {
    print(numero as Any)
}


func imprimirNum(numero :  Int?){
    
    print(numero!)
    
}

imprimirNum(numero: numero)


struct opcional{
    var numero2 : Int
    var numero3 : Int
    
    init?(numero2: Int, numero3: Int) {
        if numero2 > 4 || numero3 < 4{
            return nil
        }else{
            self.numero2 = numero2
            self.numero3 = numero3
        }
    }
    
}

var opcional2 = opcional(numero2: 2, numero3: 5)

print(opcional2?.numero2)
print(opcional2?.numero3)



class Apartamento{
    numeroApartamento : Int?
}












