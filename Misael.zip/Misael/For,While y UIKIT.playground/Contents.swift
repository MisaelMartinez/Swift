//: Playground - noun: a place where people can play

import UIKit


var NumeroAleatorio = arc4random_uniform(5) + 1
//print(NumeroAleatorio)

// Ciclo for


for index in 1...5 {
    print("\(index)\r\r")
}
var i = 0
var array = ["Hola", "Como estas?", "Mi amor,", "Adios"]
for index in array{
    
    
    if index == "Adios"{
        array[i] = "hola"
        
    }
    i += 1
    print(index)
}

print(array, "2")

for _ in 1...3{
    print("Hola mundo")
    
}



var estoEsUnaFrase = "Esto Es Una Frase"
var estoEsUnaNuevaFrase = ""
for n in estoEsUnaFrase{
    
    if n == "o"{
        estoEsUnaNuevaFrase.append("a")
        
    }else{
        estoEsUnaNuevaFrase.append(String(n))
    }
    
    
}

print(estoEsUnaNuevaFrase)
print("\(estoEsUnaFrase) \r\r")

let diccionario = ["Spaguetti": 5,"Hogar": 1, "Parque": 2, "Chedrahui" : 3 ,"Estofado": 7]
for (Lugares, numeros) in diccionario{
    
    print("Me gusta mucho el: \(Lugares) ")
    print("El numero de este lugar es: \(numeros)")

}

var numero = 3

while numero > 0{
    print(numero)
    numero -= 1
}




