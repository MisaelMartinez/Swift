//
//  ViewController.swift
//  swichTogel
//
//  Created by Macbook on 7/6/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var SwichTogel : UISwitch = {
        let Sw = UISwitch()
        Sw.isOn = true
        Sw.onTintColor = .green
        Sw.thumbTintColor = .black
        Sw.addTarget(self, action: #selector(prenderApagar), for: .touchUpInside)
        return Sw
    }()
    
    @objc func prenderApagar(){
        if SwichTogel.isOn == true{
        view.backgroundColor = .white
        }else {
            view.backgroundColor = .blue
        }
        
    }
    
    


    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(SwichTogel)
        
        view.backgroundColor = .white
        
        SwichTogel.frame = CGRect(x: view.center.x - 10, y: view.center.y - 10, width: 100, height: 20)
 
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

