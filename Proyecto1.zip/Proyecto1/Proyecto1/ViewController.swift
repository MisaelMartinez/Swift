//
//  ViewController.swift
//  Proyecto1
//
//  Created by Germán Santos Jaimes on 2/27/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var captura: UITextField!
    @IBOutlet weak var letrero: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        letrero.text = "Quihubole German"
    }



    @IBAction func clickit(_ sender: UIButton) {
        letrero.text = captura.text
    }
}

