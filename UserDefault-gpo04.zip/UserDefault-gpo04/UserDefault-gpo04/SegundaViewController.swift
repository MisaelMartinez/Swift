//
//  SegundaViewController.swift
//  UserDefault-gpo04
//
//  Created by Germán Santos Jaimes on 4/11/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class SegundaViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    
    @IBAction func logout(_ sender: UIButton) {
        
        UserDefaults.standard.set("", forKey: "informacion")
        navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
