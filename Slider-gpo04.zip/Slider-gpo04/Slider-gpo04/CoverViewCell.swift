//
//  CoverViewCell.swift
//  Slider-gpo04
//
//  Created by Germán Santos Jaimes on 4/25/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class CoverViewCell : UICollectionViewCell{
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let imageCover: UIImageView = {
       let iv = UIImageView()
        iv.image = UIImage(named: "queen")
        iv.contentMode = .scaleAspectFill
        return iv
    }()
    
    let etiqueta: UILabel = {
        let label = UILabel()
        label.text = "Queen, el mejor de los mejores"
        label.font = UIFont.systemFont(ofSize: 13)
        label.numberOfLines = 2
        return label
        
    }()
    
    func setupLayout(){
        addSubview(imageCover)
        addSubview(etiqueta)
        
        imageCover.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.width)
        etiqueta.frame = CGRect(x: 0, y: frame.width + 2, width: frame.width, height: 40)
    }
    
}
