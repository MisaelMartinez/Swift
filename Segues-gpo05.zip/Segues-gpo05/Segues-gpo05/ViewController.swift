//
//  ViewController.swift
//  Segues-gpo05
//
//  Created by Germán Santos Jaimes on 4/5/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var texto: UITextField!
    var valores = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let valorCaja = valores.object(forKey: "caja"){
            print("Hay un valor")
            texto.text = valorCaja as! String
        }else{
            print("No hay valor")
        }
        
    }

    @IBAction func nextView(_ sender: Any) {
        var contenido = texto.text
        if contenido != ""{
            print("Hay texto")
            valores.setValue(texto.text, forKey: "caja")
            
        }else{
            showError()
            self.navigationController?.pushViewController(SecondViewController(), animated: true)
            print("Cancelado")
        }
    }
    
    func showError(){
        let errorWindow = UIAlertController(title: "Error", message: "No existen datos en la caja", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        errorWindow.addAction(okAction)
        
        present(errorWindow, animated: true, completion: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("Ejecutando el segue")
    }
    
    override func performSegue(withIdentifier identifier: String, sender: Any?) {
        print("moviendome a la segunda vista")
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return true
    }
    
}

